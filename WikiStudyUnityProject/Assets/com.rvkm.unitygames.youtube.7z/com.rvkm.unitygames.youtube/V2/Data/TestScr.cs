﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Test Data", menuName = "Kaiyum/Test data(V2)", order = 54)]
public class TestScr : ScriptableObject
{
    public string tValue;
}
